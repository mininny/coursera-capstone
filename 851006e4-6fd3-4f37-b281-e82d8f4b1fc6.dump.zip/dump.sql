BEGIN TRANSACTION;
CREATE TABLE chats (
	sender VARCHAR(80) NOT NULL, 
	chat VARCHAR(120), 
	receiver VARCHAR(80), 
	PRIMARY KEY (sender), 
	UNIQUE (sender)
);
CREATE TABLE users (
	username VARCHAR(80) NOT NULL, 
	password VARCHAR(120), 
	PRIMARY KEY (username), 
	UNIQUE (username), 
	UNIQUE (password)
);
INSERT INTO "users" VALUES('asdf','asdf');
INSERT INTO "users" VALUES('asdfqwer','asdfqwer');
INSERT INTO "users" VALUES('asdfasdf','asdfasdf');
INSERT INTO "users" VALUES('asdfdf','asdfdf');
INSERT INTO "users" VALUES('asdfqr','asdfqr');
INSERT INTO "users" VALUES('asdfqw','asdfqw');
INSERT INTO "users" VALUES('asdflj','asdflj');
INSERT INTO "users" VALUES('asdfqp','asdfqp');
INSERT INTO "users" VALUES('asdfff','asdfff');
COMMIT;