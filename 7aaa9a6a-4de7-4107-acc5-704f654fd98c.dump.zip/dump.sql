BEGIN TRANSACTION;
CREATE TABLE chats (
	sender VARCHAR(80), 
	chat VARCHAR(120), 
	receiver VARCHAR(80), 
	time VARCHAR(30) NOT NULL, 
	PRIMARY KEY (time)
);
INSERT INTO "chats" VALUES('sdfa','ahaha','asfaf','2018-10-25 14:39:58');
CREATE TABLE users (
	username VARCHAR(80) NOT NULL, 
	password VARCHAR(120) NOT NULL, 
	PRIMARY KEY (username), 
	UNIQUE (username), 
	UNIQUE (password)
);
INSERT INTO "users" VALUES('asdf','$5$rounds=535000$w3cilzGiU9TsJINu$bhEslTTQrVKT3n1gwSuX8K8E4yPIWc79F02A1oBm8h1');
INSERT INTO "users" VALUES('afaf','$5$rounds=535000$fMhORqHX7xVFZeXn$h/OEcRRigN82RXsMQGn1J2pO.1UpWvDE5f89WLKKFg4');
INSERT INTO "users" VALUES('sdfa','$5$rounds=535000$Bch4JUntuS702.b8$K4njkrdOm9YnNSlI77RigumC5BWW5zCdDvLWKK9q8R.');
INSERT INTO "users" VALUES('asd','$5$rounds=535000$.NqhKHyKJsKvxwle$/197dH02ppJF4V0UcjIuIdAKj95jO.f1WlOMwtF8mI1');
COMMIT;