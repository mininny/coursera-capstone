BEGIN TRANSACTION;
CREATE TABLE chats (
	sender VARCHAR(256), 
	chat VARCHAR(256), 
	receiver VARCHAR(80), 
	time VARCHAR(30) NOT NULL, 
	PRIMARY KEY (time)
);
CREATE TABLE users (
	username VARCHAR(80) NOT NULL, 
	password VARCHAR(120) NOT NULL, 
	PRIMARY KEY (username), 
	UNIQUE (username), 
	UNIQUE (password)
);
INSERT INTO "users" VALUES('asdf','$5$rounds=535000$dA6n0smscO1Gvh1j$R3Br.OdziK7NefuDbG/TYJjBxK5SHdEn7IbFnEvNnQ8');
COMMIT;