BEGIN TRANSACTION;
CREATE TABLE chats (
	sender VARCHAR(80), 
	chat VARCHAR(120), 
	receiver VARCHAR(80), 
	time VARCHAR(30) NOT NULL, 
	PRIMARY KEY (time)
);
INSERT INTO "chats" VALUES('test','awerEnter text here...','asdf','2018-10-25 13:05:02');
CREATE TABLE users (
	username VARCHAR(80) NOT NULL, 
	password VARCHAR(120), 
	PRIMARY KEY (username), 
	UNIQUE (username), 
	UNIQUE (password)
);
INSERT INTO "users" VALUES('test','test');
INSERT INTO "users" VALUES('asdf','adsf');
COMMIT;